import java.util.ArrayList;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LanguageEnum e1= LanguageEnum.English;
		NotificationTemplate n1= new NotificationTemplate(2018, "first content ", "second subject", e1);
		INotificationTemplateDataAccessLayer test= new MySQL();
		//boolean x = test.AddTemplate(n1); // adding test 
		//test.deleteTemplate(1); // deleting test .
		NotificationTemplate n2 = new NotificationTemplate(2018,"second content ","second content temp ",e1 );
	//	test.updateTemplate(n2);
		ArrayList<NotificationTemplate> allTemplates= test.searchTemplate();// get all templates test .
		for (NotificationTemplate n:allTemplates) {
			System.out.println(n.toString()+"\n\n");
		}
	
		System.out.println((test.getTemplate(3)).toString() );// get yemplate test 
	}

}
