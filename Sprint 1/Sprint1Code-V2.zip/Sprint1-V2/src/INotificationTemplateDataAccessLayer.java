import java.util.ArrayList;

public interface INotificationTemplateDataAccessLayer {
	public boolean AddTemplate(NotificationTemplate template);
	public boolean updateTemplate(NotificationTemplate template);
	public boolean deleteTemplate(int templateID);
	public NotificationTemplate getTemplate(int id );
	public ArrayList<NotificationTemplate> searchTemplate ();
		

}
